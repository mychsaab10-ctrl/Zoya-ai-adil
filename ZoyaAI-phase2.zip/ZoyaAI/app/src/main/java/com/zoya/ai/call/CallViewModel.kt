package com.zoya.ai.call

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zoya.ai.Ids
import com.zoya.ai.Persona
import com.zoya.ai.SettingsStore
import com.zoya.ai.ZoyaPlayer
import com.zoya.ai.net.ApiErrors
import com.zoya.ai.net.ElevenLabsClient
import com.zoya.ai.net.GrokClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

enum class CallState { IDLE, LISTENING, THINKING, SPEAKING }

/** who = "you", "zoya" or "system" */
data class CallLine(val id: Long = Ids.next(), val who: String, val text: String)

/**
 * Voice call pipeline (the documented fallback, works with your ElevenLabs voice):
 *   microphone -> Android SpeechRecognizer -> Grok chat -> ElevenLabs voice -> speaker -> listen again
 */
class CallViewModel(app: Application) : AndroidViewModel(app) {

    val settings = SettingsStore(app)

    private val ctx = app.applicationContext
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val grok = GrokClient(http)
    private val eleven = ElevenLabsClient(http)
    private val player = ZoyaPlayer()
    private val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val connectivity = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    // ---- UI state ----
    var active by mutableStateOf(false); private set
    var state by mutableStateOf(CallState.IDLE); private set
    var muted by mutableStateOf(false); private set
    var seconds by mutableStateOf(0); private set
    var partial by mutableStateOf(""); private set
    var level by mutableStateOf(0f); private set
    var notice by mutableStateOf<String?>(null); private set
    var online by mutableStateOf(true); private set
    var apiProblem by mutableStateOf(false); private set
    var langTag by mutableStateOf(settings.callLang); private set
    var bargeIn by mutableStateOf(settings.callBargeIn); private set
    val lines = mutableStateListOf<CallLine>()

    val connectionLabel: String
        get() = when {
            !active -> "Not in a call"
            !online -> "No internet"
            apiProblem -> "Connection problem"
            else -> "Connected"
        }

    // ---- internals ----
    private var recognizer: SpeechRecognizer? = null
    private var recActive = false
    private var silenceCount = 0
    private var errorRetries = 0
    private var hasVoice = false
    private var turnJob: Job? = null
    private var tickJob: Job? = null
    private var restartJob: Job? = null
    private var focusRequest: AudioFocusRequest? = null
    private val history = ArrayList<Pair<String, String>>()

    // ======================= Public controls =======================

    fun setLanguage(tag: String) {
        if (active) return
        langTag = tag
        settings.callLang = tag
    }

    fun updateBargeIn(enabled: Boolean) {
        bargeIn = enabled
        settings.callBargeIn = enabled
        if (!active) return
        if (state == CallState.SPEAKING) {
            if (enabled) startListening() else stopRecognizer()
        }
    }

    fun clearNotice() {
        notice = null
    }

    fun startCall() {
        if (active) return
        if (settings.grokKey.isBlank() || settings.model.isBlank()) {
            notice = "Add your Grok API key and model in Settings first."
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            notice = "This phone has no speech recognition service. Install or enable Google speech services."
            return
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notice = "Microphone permission is required for calls."
            return
        }

        notice = null
        lines.clear()
        history.clear()
        seconds = 0
        silenceCount = 0
        errorRetries = 0
        muted = false
        apiProblem = false
        partial = ""
        online = connectivity.activeNetwork != null
        hasVoice = settings.elevenKey.isNotBlank() && settings.voiceId.isNotBlank()

        requestAudioFocus()
        registerNetwork()
        active = true
        state = CallState.THINKING

        tickJob = viewModelScope.launch {
            while (isActive) {
                delay(1000)
                seconds++
            }
        }

        if (!hasVoice) {
            addLine("system", "ElevenLabs voice isn't set up, so Zoya will answer with subtitles only.")
        }

        val greeting = if (langTag == "ur-PK") "ہاں جی، میں سن رہی ہوں۔ کہیے!" else "Hi, I'm here. What's on your mind?"
        history.add("assistant" to greeting)
        turnJob = viewModelScope.launch {
            deliver(greeting)
            finishTurn()
        }
    }

    fun endCall(reason: String? = null) {
        if (!active) return
        active = false
        turnJob?.cancel()
        tickJob?.cancel()
        restartJob?.cancel()
        player.stop()
        stopRecognizer()
        destroyRecognizer()
        unregisterNetwork()
        abandonAudioFocus()
        state = CallState.IDLE
        partial = ""
        level = 0f
        muted = false
        notice = reason
    }

    fun toggleMute() {
        if (!active) return
        muted = !muted
        if (muted) {
            stopRecognizer()
            partial = ""
            level = 0f
            if (state == CallState.LISTENING) state = CallState.IDLE
        } else {
            when (state) {
                CallState.IDLE, CallState.LISTENING -> resumeListening()
                CallState.SPEAKING -> if (bargeIn) startListening()
                CallState.THINKING -> {}
            }
        }
    }

    /** Manual barge-in: stop Zoya talking/thinking and listen to the user now. */
    fun interrupt() {
        if (!active) return
        if (state == CallState.SPEAKING || state == CallState.THINKING) {
            turnJob?.cancel()
            player.stop()
            resumeListening()
        }
    }

    // ======================= Conversation turn =======================

    private fun handleUserText(text: String) {
        turnJob?.cancel()
        player.stop()
        addLine("you", text)
        history.add("user" to text)
        state = CallState.THINKING

        turnJob = viewModelScope.launch {
            if (!online) {
                apiProblem = true
                addLine("system", "No internet connection. I'll keep listening.")
                history.removeAt(history.lastIndex)
                finishTurn()
                return@launch
            }
            val msgs = ArrayList<Pair<String, String>>()
            msgs.add("system" to Persona.systemPrompt(settings, call = true))
            msgs.addAll(history.takeLast(16))

            val r = grok.chat(settings.grokKey, settings.model, settings.temperature, msgs, maxTokens = 300)
            if (r.isFailure) {
                apiProblem = true
                addLine("system", ApiErrors.describe(r.exceptionOrNull()!!))
                history.removeAt(history.lastIndex)
                finishTurn()
                return@launch
            }
            apiProblem = false
            val reply = r.getOrThrow()
            history.add("assistant" to reply)
            deliver(reply)
            finishTurn()
        }
    }

    /** Shows subtitles, then speaks with ElevenLabs (if configured). */
    private suspend fun deliver(reply: String) {
        addLine("zoya", reply)
        if (!hasVoice) return

        val r = eleven.synthesize(settings.elevenKey, settings.voiceId, reply, ctx.cacheDir)
        if (r.isFailure) {
            apiProblem = true
            addLine("system", "Voice error: " + ApiErrors.describe(r.exceptionOrNull()!!))
            return
        }
        apiProblem = false
        state = CallState.SPEAKING
        if (bargeIn) startListening()
        val played = player.play(r.getOrThrow())
        if (played.isFailure) addLine("system", ApiErrors.describe(played.exceptionOrNull()!!))
    }

    private fun finishTurn() {
        if (active) resumeListening()
    }

    private fun resumeListening() {
        if (!active) return
        if (muted) {
            state = CallState.IDLE
            return
        }
        state = CallState.LISTENING
        startListening()
    }

    /** User started talking while Zoya was speaking (headphones mode). */
    private fun interruptForUser() {
        turnJob?.cancel()
        player.stop()
        state = CallState.LISTENING
    }

    // ======================= Speech recognition =======================

    private fun wantListen(): Boolean =
        active && !muted && (state == CallState.LISTENING || (state == CallState.SPEAKING && bargeIn))

    private fun createRecognizer(): SpeechRecognizer? {
        return try {
            SpeechRecognizer.createSpeechRecognizer(ctx).also {
                it.setRecognitionListener(listener)
                recognizer = it
            }
        } catch (e: Exception) {
            addLine("system", "Could not start speech recognition.")
            null
        }
    }

    /** Only one microphone session at a time: recActive guards against duplicates. */
    private fun startListening() {
        if (!active || muted || recActive) return
        val rec = recognizer ?: createRecognizer() ?: return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        recActive = true
        partial = ""
        try {
            rec.startListening(intent)
        } catch (e: Exception) {
            recActive = false
            retryOrEnd(SpeechRecognizer.ERROR_CLIENT)
        }
    }

    private fun stopRecognizer() {
        restartJob?.cancel()
        try { recognizer?.cancel() } catch (_: Exception) {}
        recActive = false
    }

    private fun destroyRecognizer() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
        recActive = false
    }

    private fun resetRecognizer() {
        stopRecognizer()
        destroyRecognizer()
    }

    private fun scheduleRestart(delayMs: Long) {
        restartJob?.cancel()
        restartJob = viewModelScope.launch {
            delay(delayMs)
            if (wantListen()) startListening()
        }
    }

    private fun onSilence() {
        silenceCount++
        if (silenceCount == 4) {
            addLine("system", "I'm still here. Say something whenever you're ready.")
        }
        if (silenceCount >= 10) {
            endCall("Call ended after a long silence.")
            return
        }
        if (wantListen()) scheduleRestart(200)
    }

    private fun retryOrEnd(code: Int) {
        errorRetries++
        if (errorRetries > 4) {
            endCall("Speech recognition keeps failing (${describeRecError(code)}). Check your connection and try again.")
            return
        }
        if (code == SpeechRecognizer.ERROR_NETWORK ||
            code == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
            code == SpeechRecognizer.ERROR_SERVER
        ) {
            apiProblem = true
        }
        if (errorRetries == 1) addLine("system", "Trouble hearing you (${describeRecError(code)}). Retrying…")
        resetRecognizer()
        scheduleRestart(800L * errorRetries)
    }

    private fun describeRecError(code: Int) = when (code) {
        1, 2 -> "network problem"
        3 -> "audio recording problem"
        4, 11 -> "speech server problem"
        5 -> "recognizer error"
        10 -> "too many requests"
        else -> "error $code"
    }

    private fun handleRecError(code: Int) {
        if (!active) return
        when (code) {
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT, SpeechRecognizer.ERROR_NO_MATCH -> {
                if (state == CallState.SPEAKING) {
                    if (wantListen()) scheduleRestart(300)
                } else if (state == CallState.LISTENING) {
                    onSilence()
                }
            }
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                resetRecognizer()
                scheduleRestart(600)
            }
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                endCall("Microphone permission was denied. Allow it in app settings.")
            12, 13 ->
                endCall("This speech language isn't available on your phone. Choose another language.")
            else -> retryOrEnd(code)
        }
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}

        override fun onBeginningOfSpeech() {
            if (state == CallState.SPEAKING) interruptForUser()
        }

        override fun onRmsChanged(rmsdB: Float) {
            level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = firstResult(partialResults)
            if (t.isNotBlank()) {
                partial = t
                if (state == CallState.SPEAKING) interruptForUser()
            }
        }

        override fun onResults(results: Bundle?) {
            recActive = false
            level = 0f
            partial = ""
            val t = firstResult(results).trim()
            if (t.isEmpty()) {
                if (state == CallState.LISTENING) onSilence()
                return
            }
            silenceCount = 0
            errorRetries = 0
            apiProblem = false
            handleUserText(t)
        }

        override fun onError(error: Int) {
            recActive = false
            level = 0f
            partial = ""
            handleRecError(error)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    // ======================= Audio focus & network =======================

    private fun requestAudioFocus() {
        try {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener { /* ignored on purpose */ }
                .build()
            audioManager.requestAudioFocus(req)
            focusRequest = req
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus() {
        try {
            focusRequest?.let { audioManager.abandonAudioFocusRequest(it) }
        } catch (_: Exception) {
        }
        focusRequest = null
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            viewModelScope.launch { online = true }
        }

        override fun onLost(network: Network) {
            viewModelScope.launch { online = false }
        }
    }
    private var netRegistered = false

    private fun registerNetwork() {
        if (netRegistered) return
        try {
            connectivity.registerDefaultNetworkCallback(netCallback)
            netRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun unregisterNetwork() {
        if (!netRegistered) return
        try {
            connectivity.unregisterNetworkCallback(netCallback)
        } catch (_: Exception) {
        }
        netRegistered = false
    }

    // ======================= Helpers =======================

    private fun addLine(who: String, text: String) {
        lines.add(CallLine(who = who, text = text))
        if (lines.size > 100) lines.removeAt(0)
    }

    override fun onCleared() {
        endCall(null)
        super.onCleared()
    }
}
