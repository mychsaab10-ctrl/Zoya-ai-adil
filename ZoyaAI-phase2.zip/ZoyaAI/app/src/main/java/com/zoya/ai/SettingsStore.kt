package com.zoya.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * All settings live in EncryptedSharedPreferences (AES-256, key kept in Android Keystore).
 * API keys are never written to logs or source code.
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences = open(context.applicationContext)

    var grokKey: String
        get() = prefs.getString("grok_key", "") ?: ""
        set(v) = prefs.edit().putString("grok_key", v.trim()).apply()

    var model: String
        get() = prefs.getString("model", "") ?: ""
        set(v) = prefs.edit().putString("model", v.trim()).apply()

    var temperature: Float
        get() = prefs.getFloat("temperature", 0.8f)
        set(v) = prefs.edit().putFloat("temperature", v).apply()

    var elevenKey: String
        get() = prefs.getString("eleven_key", "") ?: ""
        set(v) = prefs.edit().putString("eleven_key", v.trim()).apply()

    var voiceId: String
        get() = prefs.getString("voice_id", "") ?: ""
        set(v) = prefs.edit().putString("voice_id", v.trim()).apply()

    var voiceEnabled: Boolean
        get() = prefs.getBoolean("voice_enabled", true)
        set(v) = prefs.edit().putBoolean("voice_enabled", v).apply()

    var userName: String
        get() = prefs.getString("user_name", "") ?: ""
        set(v) = prefs.edit().putString("user_name", v.trim()).apply()

    /** Things Zoya should remember about you (editable "memory"). */
    var userNotes: String
        get() = prefs.getString("user_notes", "") ?: ""
        set(v) = prefs.edit().putString("user_notes", v.trim()).apply()

    var style: String
        get() = prefs.getString("style", Persona.STYLES.first()) ?: Persona.STYLES.first()
        set(v) = prefs.edit().putString("style", v).apply()

    var language: String
        get() = prefs.getString("language", Persona.LANGUAGES.first()) ?: Persona.LANGUAGES.first()
        set(v) = prefs.edit().putString("language", v).apply()

    var customInstructions: String
        get() = prefs.getString("custom", "") ?: ""
        set(v) = prefs.edit().putString("custom", v.trim()).apply()

    /** BCP-47 tag used by speech recognition during calls (en-US, en-IN, ur-PK). */
    var callLang: String
        get() = prefs.getString("call_lang", "en-US") ?: "en-US"
        set(v) = prefs.edit().putString("call_lang", v).apply()

    /** true = Zoya listens while speaking so you can interrupt by talking (use headphones). */
    var callBargeIn: Boolean
        get() = prefs.getBoolean("call_barge_in", false)
        set(v) = prefs.edit().putBoolean("call_barge_in", v).apply()

    companion object {
        private const val FILE = "zoya_secure_settings"

        private fun open(ctx: Context): SharedPreferences {
            fun build(): SharedPreferences {
                val masterKey = MasterKey.Builder(ctx)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build()
                return EncryptedSharedPreferences.create(
                    ctx,
                    FILE,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
                )
            }
            return try {
                build()
            } catch (e: Exception) {
                // Keystore data can become unreadable (e.g. after a restore). Start fresh.
                ctx.deleteSharedPreferences(FILE)
                build()
            }
        }
    }
}
