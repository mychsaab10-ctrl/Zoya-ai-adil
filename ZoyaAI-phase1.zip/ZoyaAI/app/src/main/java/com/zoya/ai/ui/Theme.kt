package com.zoya.ai.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun ZoyaTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFFFF6FA5),
            onPrimary = Color(0xFF3A0020),
            secondary = Color(0xFFB39DDB),
            background = Color(0xFF14101A),
            surface = Color(0xFF1D1825),
            onBackground = Color(0xFFF3EAF5),
            onSurface = Color(0xFFF3EAF5),
            surfaceVariant = Color(0xFF2A2333),
            onSurfaceVariant = Color(0xFFD7C9DD)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFFD81B60),
            onPrimary = Color.White,
            secondary = Color(0xFF7E57C2),
            background = Color(0xFFFFF7FA),
            surface = Color.White,
            onBackground = Color(0xFF241A28),
            onSurface = Color(0xFF241A28),
            surfaceVariant = Color(0xFFF6E9EF),
            onSurfaceVariant = Color(0xFF4A3A4F)
        )
    }
    MaterialTheme(colorScheme = colors, content = content)
}
