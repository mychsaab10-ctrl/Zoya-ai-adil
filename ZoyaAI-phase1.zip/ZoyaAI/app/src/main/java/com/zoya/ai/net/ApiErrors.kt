package com.zoya.ai.net

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

class ApiException(message: String) : Exception(message)

object ApiErrors {

    fun describe(e: Throwable): String = when (e) {
        is ApiException -> e.message ?: "Request failed."
        is UnknownHostException, is ConnectException ->
            "Can't reach the server. Check your internet connection."
        is SocketTimeoutException -> "The request timed out. Please try again."
        is SSLException -> "Secure connection failed. Check your network and phone date/time."
        is IOException -> "Network error. Check your connection."
        is IllegalArgumentException ->
            "A saved value looks invalid. Re-enter your key / ID without spaces or line breaks."
        else -> "Unexpected error (${e.javaClass.simpleName})."
    }

    fun http(service: String, code: Int, body: String): ApiException {
        val detail = serverMessage(body)
        val base = when {
            code == 401 -> "$service rejected the credentials (401). Check your API key."
            code == 403 -> "$service denied access (403). The key may lack permission."
            code == 404 -> "$service could not find that resource (404). Check the model name / Voice ID."
            code == 422 || code == 400 -> "$service did not accept the request ($code)."
            code == 429 -> "$service rate limit or quota reached (429). Try again later."
            code >= 500 -> "$service is having problems ($code). Try again later."
            else -> "$service returned error $code."
        }
        return ApiException(if (detail.isNullOrBlank()) base else "$base Server says: $detail")
    }

    private fun serverMessage(body: String): String? {
        try {
            val j = JSONObject(body)
            val err = j.opt("error")
            if (err is String && err.isNotBlank()) return err.take(200)
            if (err is JSONObject) {
                val m = err.optString("message")
                if (m.isNotBlank()) return m.take(200)
            }
            val d = j.opt("detail")
            if (d is String && d.isNotBlank()) return d.take(200)
            if (d is JSONObject) {
                val m = d.optString("message")
                if (m.isNotBlank()) return m.take(200)
            }
            if (d is JSONArray && d.length() > 0) {
                val first = d.optJSONObject(0)
                val m = first?.optString("msg").orEmpty()
                if (m.isNotBlank()) return m.take(200)
            }
            val m = j.optString("message")
            if (m.isNotBlank()) return m.take(200)
        } catch (e: Exception) {
            // not JSON
        }
        return null
    }
}
