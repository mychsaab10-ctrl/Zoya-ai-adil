package com.zoya.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zoya.ai.ui.ChatScreen
import com.zoya.ai.ui.SettingsScreen
import com.zoya.ai.ui.ZoyaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ZoyaTheme {
                ZoyaApp()
            }
        }
    }
}

@Composable
fun ZoyaApp() {
    val vm: ChatViewModel = viewModel()
    var showSettings by rememberSaveable { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (showSettings) {
            BackHandler { showSettings = false }
            SettingsScreen(vm = vm, onBack = { showSettings = false })
        } else {
            ChatScreen(vm = vm, onOpenSettings = { showSettings = true })
        }
    }
}
