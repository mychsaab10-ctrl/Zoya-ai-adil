package com.zoya.ai.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

/** ElevenLabs Text-to-Speech: POST https://api.elevenlabs.io/v1/text-to-speech/{voice_id} */
class ElevenLabsClient(private val http: OkHttpClient) {

    companion object {
        private const val TTS_MODEL = "eleven_multilingual_v2"
        private const val MAX_CHARS = 900
    }

    /** Removes markdown/emoji so the voice doesn't read symbols aloud. */
    fun cleanForSpeech(text: String): String {
        return text
            .replace(Regex("[*_#`~>]"), "")
            .replace(Regex("[\\p{So}\\p{Cs}]"), "")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(MAX_CHARS)
    }

    /** Returns an .mp3 file in cacheDir. The caller deletes it after playing. */
    suspend fun synthesize(
        apiKey: String,
        voiceId: String,
        text: String,
        cacheDir: File
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val clean = cleanForSpeech(text)
            if (clean.isEmpty()) throw ApiException("Nothing to speak.")

            val url = HttpUrl.Builder()
                .scheme("https")
                .host("api.elevenlabs.io")
                .addPathSegments("v1/text-to-speech")
                .addPathSegment(voiceId.trim())
                .addQueryParameter("output_format", "mp3_44100_128")
                .build()

            val payload = JSONObject()
                .put("text", clean)
                .put("model_id", TTS_MODEL)
                .put(
                    "voice_settings",
                    JSONObject().put("stability", 0.5).put("similarity_boost", 0.8)
                )

            val req = Request.Builder()
                .url(url)
                .header("xi-api-key", apiKey.trim())
                .header("Accept", "audio/mpeg")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw ApiErrors.http("ElevenLabs", resp.code, resp.body?.string().orEmpty())
                }
                val bytes = resp.body?.bytes() ?: ByteArray(0)
                if (bytes.isEmpty()) throw ApiException("ElevenLabs returned no audio.")
                val file = File(cacheDir, "zoya_tts_${System.nanoTime()}.mp3")
                file.writeBytes(bytes)
                Result.success(file)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
