# Zoya AI — Phase 1 (Foundation)

Android app (Kotlin + Jetpack Compose). Package: `com.zoya.ai`.

**Phase 1 includes:** text chat with Zoya (Grok), ElevenLabs voice replies, encrypted Settings
(API keys, Voice ID, model picker, temperature, personality, memory notes), connection tests,
and a GitHub Actions workflow that builds the APK for you.

## Build the APK from your phone (Termux + GitHub)

1. Create a free GitHub account, then create a **new empty repository** named `ZoyaAI`
   (no README). Create a **Personal Access Token**: GitHub → Settings → Developer settings →
   Personal access tokens → Tokens (classic) → tick `repo` and `workflow` → copy it.
2. Install **Termux** (from F-Droid) and run:
   ```
   termux-setup-storage
   pkg update && pkg install git unzip
   cd ~
   unzip ~/storage/downloads/ZoyaAI-phase1.zip
   cd ZoyaAI
   git init -b main
   git config user.name "Your Name"
   git config user.email "you@example.com"
   git add .
   git commit -m "Zoya AI phase 1"
   git remote add origin https://github.com/YOUR_USERNAME/ZoyaAI.git
   git push -u origin main
   ```
   When asked for a password, paste your **token** (not your GitHub password).
3. Open the repo on GitHub → **Actions** tab → "Build Zoya AI APK" runs automatically
   (about 5–8 minutes the first time). 
4. Open the finished run → **Artifacts** → download `ZoyaAI-debug-apk` (a zip) → extract →
   install `app-debug.apk` (allow "Install unknown apps" for your browser/file manager).

If the build fails, open the failed run, copy the red error lines and send them to Claude.

## First use

1. Open Zoya AI → ⚙ Settings.
2. Paste your **xAI API key** (console.x.ai) → **Test**. This lists the models your key can use.
   Pick one with **Pick model**, **Save**, then **Test** again.
3. (Optional) Paste your **ElevenLabs API key** and **Voice ID** → **Test voice** → **Save**.
4. Go back and chat.

## Security notes

- Keys are never in the source code. They are stored with AES-256 `EncryptedSharedPreferences`
  (key held in the Android Keystore) and are never logged.
- Never put a real key inside the app code or APK: anyone can extract it from an APK.
  That is why you type it into Settings at runtime.
- A key on your own phone can still be read if the phone is rooted/compromised. Use keys with
  spending limits, and revoke them if you lose the device.
- ElevenLabs bills per character spoken. Zoya trims each spoken reply to about 900 characters.

## Project layout

```
settings.gradle.kts, build.gradle.kts, gradle.properties
.github/workflows/build-apk.yml
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/res/...                       (icon, theme, strings)
app/src/main/java/com/zoya/ai/
  MainActivity.kt        app entry + navigation
  ChatViewModel.kt       chat, voice, tests, history
  SettingsStore.kt       encrypted settings
  Persona.kt             Zoya's personality prompt
  ZoyaPlayer.kt          audio playback
  Models.kt
  net/GrokClient.kt      xAI API (OpenAI-compatible)
  net/ElevenLabsClient.kt  ElevenLabs text-to-speech
  net/ApiErrors.kt       friendly error messages
  ui/ChatScreen.kt, ui/SettingsScreen.kt, ui/Theme.kt
```

## Coming next

Phase 2: voice call mode (speech-to-text, listening/thinking/speaking loop, barge-in, subtitles).
Phase 3: phone automation. Phase 4: coding mode.
